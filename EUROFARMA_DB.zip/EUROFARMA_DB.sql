--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4
-- Dumped by pg_dump version 16.4

-- Started on 2024-08-29 22:06:56

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- TOC entry 4906 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 227 (class 1259 OID 16529)
-- Name: beneficios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.beneficios (
    beneficio_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text
);


ALTER TABLE public.beneficios OWNER TO postgres;

--
-- TOC entry 226 (class 1259 OID 16528)
-- Name: beneficios_beneficio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.beneficios_beneficio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.beneficios_beneficio_id_seq OWNER TO postgres;

--
-- TOC entry 4907 (class 0 OID 0)
-- Dependencies: 226
-- Name: beneficios_beneficio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.beneficios_beneficio_id_seq OWNED BY public.beneficios.beneficio_id;


--
-- TOC entry 219 (class 1259 OID 16468)
-- Name: cargos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cargos (
    cargo_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    departamento_id integer
);


ALTER TABLE public.cargos OWNER TO postgres;

--
-- TOC entry 218 (class 1259 OID 16467)
-- Name: cargos_cargo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cargos_cargo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cargos_cargo_id_seq OWNER TO postgres;

--
-- TOC entry 4908 (class 0 OID 0)
-- Dependencies: 218
-- Name: cargos_cargo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cargos_cargo_id_seq OWNED BY public.cargos.cargo_id;


--
-- TOC entry 221 (class 1259 OID 16482)
-- Name: colaboradores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.colaboradores (
    colaborador_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    data_admissao date NOT NULL,
    cargo_id integer,
    departamento_id integer
);


ALTER TABLE public.colaboradores OWNER TO postgres;

--
-- TOC entry 220 (class 1259 OID 16481)
-- Name: colaboradores_colaborador_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.colaboradores_colaborador_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.colaboradores_colaborador_id_seq OWNER TO postgres;

--
-- TOC entry 4909 (class 0 OID 0)
-- Dependencies: 220
-- Name: colaboradores_colaborador_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.colaboradores_colaborador_id_seq OWNED BY public.colaboradores.colaborador_id;


--
-- TOC entry 231 (class 1259 OID 16552)
-- Name: complementos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.complementos (
    complemento_id integer NOT NULL,
    colaborador_id integer,
    processo_id integer,
    feedback text,
    data_avaliacao date
);


ALTER TABLE public.complementos OWNER TO postgres;

--
-- TOC entry 230 (class 1259 OID 16551)
-- Name: complementos_complemento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.complementos_complemento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.complementos_complemento_id_seq OWNER TO postgres;

--
-- TOC entry 4910 (class 0 OID 0)
-- Dependencies: 230
-- Name: complementos_complemento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.complementos_complemento_id_seq OWNED BY public.complementos.complemento_id;


--
-- TOC entry 217 (class 1259 OID 16459)
-- Name: departamentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departamentos (
    departamento_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text
);


ALTER TABLE public.departamentos OWNER TO postgres;

--
-- TOC entry 216 (class 1259 OID 16458)
-- Name: departamentos_departamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.departamentos_departamento_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.departamentos_departamento_id_seq OWNER TO postgres;

--
-- TOC entry 4911 (class 0 OID 0)
-- Dependencies: 216
-- Name: departamentos_departamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.departamentos_departamento_id_seq OWNED BY public.departamentos.departamento_id;


--
-- TOC entry 229 (class 1259 OID 16538)
-- Name: materiais; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.materiais (
    material_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    tipo character varying(50) NOT NULL,
    link text,
    modulo_id integer
);


ALTER TABLE public.materiais OWNER TO postgres;

--
-- TOC entry 228 (class 1259 OID 16537)
-- Name: materiais_material_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.materiais_material_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.materiais_material_id_seq OWNER TO postgres;

--
-- TOC entry 4912 (class 0 OID 0)
-- Dependencies: 228
-- Name: materiais_material_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.materiais_material_id_seq OWNED BY public.materiais.material_id;


--
-- TOC entry 225 (class 1259 OID 16515)
-- Name: modulos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.modulos (
    modulo_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    processo_id integer
);


ALTER TABLE public.modulos OWNER TO postgres;

--
-- TOC entry 224 (class 1259 OID 16514)
-- Name: modulos_modulo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.modulos_modulo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.modulos_modulo_id_seq OWNER TO postgres;

--
-- TOC entry 4913 (class 0 OID 0)
-- Dependencies: 224
-- Name: modulos_modulo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.modulos_modulo_id_seq OWNED BY public.modulos.modulo_id;


--
-- TOC entry 223 (class 1259 OID 16501)
-- Name: processos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.processos (
    processo_id integer NOT NULL,
    nome character varying(100) NOT NULL,
    descricao text,
    departamento_id integer,
    tempo_estimado interval
);


ALTER TABLE public.processos OWNER TO postgres;

--
-- TOC entry 222 (class 1259 OID 16500)
-- Name: processos_processo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.processos_processo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.processos_processo_id_seq OWNER TO postgres;

--
-- TOC entry 4914 (class 0 OID 0)
-- Dependencies: 222
-- Name: processos_processo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.processos_processo_id_seq OWNED BY public.processos.processo_id;


--
-- TOC entry 4729 (class 2604 OID 16532)
-- Name: beneficios beneficio_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beneficios ALTER COLUMN beneficio_id SET DEFAULT nextval('public.beneficios_beneficio_id_seq'::regclass);


--
-- TOC entry 4725 (class 2604 OID 16471)
-- Name: cargos cargo_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargos ALTER COLUMN cargo_id SET DEFAULT nextval('public.cargos_cargo_id_seq'::regclass);


--
-- TOC entry 4726 (class 2604 OID 16485)
-- Name: colaboradores colaborador_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaboradores ALTER COLUMN colaborador_id SET DEFAULT nextval('public.colaboradores_colaborador_id_seq'::regclass);


--
-- TOC entry 4731 (class 2604 OID 16555)
-- Name: complementos complemento_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.complementos ALTER COLUMN complemento_id SET DEFAULT nextval('public.complementos_complemento_id_seq'::regclass);


--
-- TOC entry 4724 (class 2604 OID 16462)
-- Name: departamentos departamento_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamentos ALTER COLUMN departamento_id SET DEFAULT nextval('public.departamentos_departamento_id_seq'::regclass);


--
-- TOC entry 4730 (class 2604 OID 16541)
-- Name: materiais material_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.materiais ALTER COLUMN material_id SET DEFAULT nextval('public.materiais_material_id_seq'::regclass);


--
-- TOC entry 4728 (class 2604 OID 16518)
-- Name: modulos modulo_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modulos ALTER COLUMN modulo_id SET DEFAULT nextval('public.modulos_modulo_id_seq'::regclass);


--
-- TOC entry 4727 (class 2604 OID 16504)
-- Name: processos processo_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processos ALTER COLUMN processo_id SET DEFAULT nextval('public.processos_processo_id_seq'::regclass);


--
-- TOC entry 4745 (class 2606 OID 16536)
-- Name: beneficios beneficios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beneficios
    ADD CONSTRAINT beneficios_pkey PRIMARY KEY (beneficio_id);


--
-- TOC entry 4735 (class 2606 OID 16475)
-- Name: cargos cargos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargos
    ADD CONSTRAINT cargos_pkey PRIMARY KEY (cargo_id);


--
-- TOC entry 4737 (class 2606 OID 16489)
-- Name: colaboradores colaboradores_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaboradores
    ADD CONSTRAINT colaboradores_email_key UNIQUE (email);


--
-- TOC entry 4739 (class 2606 OID 16487)
-- Name: colaboradores colaboradores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaboradores
    ADD CONSTRAINT colaboradores_pkey PRIMARY KEY (colaborador_id);


--
-- TOC entry 4749 (class 2606 OID 16559)
-- Name: complementos complementos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.complementos
    ADD CONSTRAINT complementos_pkey PRIMARY KEY (complemento_id);


--
-- TOC entry 4733 (class 2606 OID 16466)
-- Name: departamentos departamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamentos
    ADD CONSTRAINT departamentos_pkey PRIMARY KEY (departamento_id);


--
-- TOC entry 4747 (class 2606 OID 16545)
-- Name: materiais materiais_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.materiais
    ADD CONSTRAINT materiais_pkey PRIMARY KEY (material_id);


--
-- TOC entry 4743 (class 2606 OID 16522)
-- Name: modulos modulos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modulos
    ADD CONSTRAINT modulos_pkey PRIMARY KEY (modulo_id);


--
-- TOC entry 4741 (class 2606 OID 16508)
-- Name: processos processos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processos
    ADD CONSTRAINT processos_pkey PRIMARY KEY (processo_id);


--
-- TOC entry 4750 (class 2606 OID 16476)
-- Name: cargos cargos_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cargos
    ADD CONSTRAINT cargos_departamento_id_fkey FOREIGN KEY (departamento_id) REFERENCES public.departamentos(departamento_id);


--
-- TOC entry 4751 (class 2606 OID 16490)
-- Name: colaboradores colaboradores_cargo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaboradores
    ADD CONSTRAINT colaboradores_cargo_id_fkey FOREIGN KEY (cargo_id) REFERENCES public.cargos(cargo_id);


--
-- TOC entry 4752 (class 2606 OID 16495)
-- Name: colaboradores colaboradores_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.colaboradores
    ADD CONSTRAINT colaboradores_departamento_id_fkey FOREIGN KEY (departamento_id) REFERENCES public.departamentos(departamento_id);


--
-- TOC entry 4756 (class 2606 OID 16560)
-- Name: complementos complementos_colaborador_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.complementos
    ADD CONSTRAINT complementos_colaborador_id_fkey FOREIGN KEY (colaborador_id) REFERENCES public.colaboradores(colaborador_id);


--
-- TOC entry 4757 (class 2606 OID 16565)
-- Name: complementos complementos_processo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.complementos
    ADD CONSTRAINT complementos_processo_id_fkey FOREIGN KEY (processo_id) REFERENCES public.processos(processo_id);


--
-- TOC entry 4755 (class 2606 OID 16546)
-- Name: materiais materiais_modulo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.materiais
    ADD CONSTRAINT materiais_modulo_id_fkey FOREIGN KEY (modulo_id) REFERENCES public.modulos(modulo_id);


--
-- TOC entry 4754 (class 2606 OID 16523)
-- Name: modulos modulos_processo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.modulos
    ADD CONSTRAINT modulos_processo_id_fkey FOREIGN KEY (processo_id) REFERENCES public.processos(processo_id);


--
-- TOC entry 4753 (class 2606 OID 16509)
-- Name: processos processos_departamento_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processos
    ADD CONSTRAINT processos_departamento_id_fkey FOREIGN KEY (departamento_id) REFERENCES public.departamentos(departamento_id);


-- Completed on 2024-08-29 22:06:56

--
-- PostgreSQL database dump complete
--

